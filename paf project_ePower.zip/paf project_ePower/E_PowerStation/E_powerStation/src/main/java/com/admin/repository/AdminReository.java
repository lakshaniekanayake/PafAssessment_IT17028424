package com.admin.repository;

public class AdminReository {

}
