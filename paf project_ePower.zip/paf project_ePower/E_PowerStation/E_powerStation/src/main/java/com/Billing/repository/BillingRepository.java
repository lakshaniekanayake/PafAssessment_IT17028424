package com.shoppingcart.repository;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.shoppingcart.model.ShoppingCart;

public class ShoppingcartRepository {

	public ShoppingCart save(@Valid ShoppingCart itm) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ShoppingCart> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public Optional<ShoppingCart> findById(Long itmId) {
		// TODO Auto-generated method stub
		return null;
	}

	public void delete(ShoppingCart itm) {
		// TODO Auto-generated method stub
		
	}

}

