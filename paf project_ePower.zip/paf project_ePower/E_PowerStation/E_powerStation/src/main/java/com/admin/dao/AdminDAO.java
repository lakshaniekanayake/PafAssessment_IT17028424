package com.admin.dao;

public class AdminDAO {

}
