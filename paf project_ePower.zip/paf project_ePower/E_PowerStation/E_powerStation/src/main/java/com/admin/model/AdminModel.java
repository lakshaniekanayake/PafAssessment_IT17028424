package com.admin.model;

public class AdminModel {

}
